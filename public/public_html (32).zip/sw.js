/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-135db600'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-512x512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "pwa-192x192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "placeholder.svg",
    "revision": "35707bd9960ba5281c72af927b79291f"
  }, {
    "url": "index.html",
    "revision": "539949ee274a053d54b0e58f6d215728"
  }, {
    "url": "favicon.ico",
    "revision": "574a19b6745bdb5515ca6dcff63d29af"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "icons/icon-512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "icons/icon-192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "assets/workHoursTracker-fNYfLEcE.js",
    "revision": null
  }, {
    "url": "assets/wallet-lbRIBsaG.js",
    "revision": null
  }, {
    "url": "assets/vendor-ui-DQrUE-Jh.js",
    "revision": null
  }, {
    "url": "assets/vendor-supabase-D_t8kiev.js",
    "revision": null
  }, {
    "url": "assets/vendor-react-B2AhFMKx.js",
    "revision": null
  }, {
    "url": "assets/users-B9oBGTNW.js",
    "revision": null
  }, {
    "url": "assets/user-check-BhnWKPwG.js",
    "revision": null
  }, {
    "url": "assets/triangle-alert-xSw13gr4.js",
    "revision": null
  }, {
    "url": "assets/sliders-horizontal-VhAY_XuL.js",
    "revision": null
  }, {
    "url": "assets/send-CmabHivR.js",
    "revision": null
  }, {
    "url": "assets/save-BDhPLmQ2.js",
    "revision": null
  }, {
    "url": "assets/receipt-DprXsZBo.js",
    "revision": null
  }, {
    "url": "assets/priceAnomaly-BRr1tbxR.js",
    "revision": null
  }, {
    "url": "assets/pencil-Dft4OS2e.js",
    "revision": null
  }, {
    "url": "assets/partsStore-DvlEJfaT.js",
    "revision": null
  }, {
    "url": "assets/package-D6f2ij_9.js",
    "revision": null
  }, {
    "url": "assets/layers-CP4uDOPy.js",
    "revision": null
  }, {
    "url": "assets/info-CLF-Qyhh.js",
    "revision": null
  }, {
    "url": "assets/index-t1cdkIlu.css",
    "revision": null
  }, {
    "url": "assets/index-01DicLWN.js",
    "revision": null
  }, {
    "url": "assets/history-CEZdLR2w.js",
    "revision": null
  }, {
    "url": "assets/filter-C55kqkY8.js",
    "revision": null
  }, {
    "url": "assets/file-spreadsheet-D9_JASc0.js",
    "revision": null
  }, {
    "url": "assets/external-link-BK0_HjR4.js",
    "revision": null
  }, {
    "url": "assets/exportUtils-BU_IvsFA.js",
    "revision": null
  }, {
    "url": "assets/database-backup-DEKhhT3n.js",
    "revision": null
  }, {
    "url": "assets/database-_hRhogMV.js",
    "revision": null
  }, {
    "url": "assets/cloud-upload-CTlOgulv.js",
    "revision": null
  }, {
    "url": "assets/clock-3-BxoqKw53.js",
    "revision": null
  }, {
    "url": "assets/clipboard-check-BKYjsdBw.js",
    "revision": null
  }, {
    "url": "assets/circle-x-DOaEVLZh.js",
    "revision": null
  }, {
    "url": "assets/calendar-days-DbjbS_aU.js",
    "revision": null
  }, {
    "url": "assets/calendar-DHli45Y0.js",
    "revision": null
  }, {
    "url": "assets/bell-3_I0Gd86.js",
    "revision": null
  }, {
    "url": "assets/ban-C4Uh2579.js",
    "revision": null
  }, {
    "url": "assets/arrow-right-qVO0QBoY.js",
    "revision": null
  }, {
    "url": "assets/activity-DeCj4mdQ.js",
    "revision": null
  }, {
    "url": "assets/ZonesPage-BavP_zpY.js",
    "revision": null
  }, {
    "url": "assets/TriangleKeyLocationsPage-GeU9O1j6.js",
    "revision": null
  }, {
    "url": "assets/TechnicianMobileApp-CCeHQw-Y.js",
    "revision": null
  }, {
    "url": "assets/TechnicianDashboard-D85iiYX-.js",
    "revision": null
  }, {
    "url": "assets/SystemHealthPage-DT7l_xEo.js",
    "revision": null
  }, {
    "url": "assets/StaffPage-BojUK4hF.js",
    "revision": null
  }, {
    "url": "assets/SmartAssistantPage-CNnb7mDt.js",
    "revision": null
  }, {
    "url": "assets/ServiceForm-Cr6zQdtp.js",
    "revision": null
  }, {
    "url": "assets/ScheduleManagementPage-CG00F6AP.js",
    "revision": null
  }, {
    "url": "assets/PartsPage-Dljse8K_.js",
    "revision": null
  }, {
    "url": "assets/OperationalReadinessPage-BVorVsV1.js",
    "revision": null
  }, {
    "url": "assets/NumberStepper-DEQ6a_cT.js",
    "revision": null
  }, {
    "url": "assets/NotificationsPanel-B65BO3U_.js",
    "revision": null
  }, {
    "url": "assets/MarketingFlyout-DUR8dQVw.js",
    "revision": null
  }, {
    "url": "assets/IncompleteDataCenter-HhTReIAL.js",
    "revision": null
  }, {
    "url": "assets/DataIntegrityPage-DXZPPRH8.js",
    "revision": null
  }, {
    "url": "assets/CustomersPage-CgAF1H1z.js",
    "revision": null
  }, {
    "url": "assets/CustomerReportsPage-C0_sNcfh.js",
    "revision": null
  }, {
    "url": "assets/CustomerPortalView-CqI8MsBg.js",
    "revision": null
  }, {
    "url": "assets/CsvUploadPage-erExLZQ4.js",
    "revision": null
  }, {
    "url": "assets/CpanelSettingsPage-DNVAyLJ3.js",
    "revision": null
  }, {
    "url": "assets/ContractsPage-a2nWvqMJ.js",
    "revision": null
  }, {
    "url": "assets/ContractView-1pSmnL7o.js",
    "revision": null
  }, {
    "url": "assets/ChecklistSettingsPage-CDZPfgr9.js",
    "revision": null
  }, {
    "url": "assets/AuditHistoryPage-BbVlQsCa.js",
    "revision": null
  }, {
    "url": "assets/AdminQuickServiceCompletionPage-6muMRPWM.js",
    "revision": null
  }, {
    "url": "assets/AccessManagementPage-BQe45RCW.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "favicon.ico",
    "revision": "574a19b6745bdb5515ca6dcff63d29af"
  }, {
    "url": "pwa-192x192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "icons/icon-192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "icons/icon-512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "manifest.webmanifest",
    "revision": "1f1216864a5c781887515c844f834ec2"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(({
    url
  }) => /\/assets\/xlsx-.*\.js$/i.test(url.pathname), new workbox.StaleWhileRevalidate({
    "cacheName": "tlift-excel-on-demand-v1",
    plugins: [new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(({
    url
  }) => url.pathname.includes("/uploads/") || /\.(?:jpg|jpeg|png|webp)$/i.test(url.pathname), new workbox.CacheFirst({
    "cacheName": "tlift-photos-v1",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 180,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(({
    url
  }) => url.pathname.endsWith("/api/sync.php") || url.pathname.endsWith("/sync.php"), new workbox.NetworkOnly(), 'GET');

}));
