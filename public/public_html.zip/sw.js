/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-135db600'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-512x512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "pwa-192x192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "placeholder.svg",
    "revision": "35707bd9960ba5281c72af927b79291f"
  }, {
    "url": "index.html",
    "revision": "7daeb3b5c0a03339b1a0a65778411b18"
  }, {
    "url": "favicon.ico",
    "revision": "574a19b6745bdb5515ca6dcff63d29af"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "icons/icon-512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "icons/icon-192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "assets/workHoursTracker-fNYfLEcE.js",
    "revision": null
  }, {
    "url": "assets/wallet-BV7wV2I5.js",
    "revision": null
  }, {
    "url": "assets/vendor-ui-DQrUE-Jh.js",
    "revision": null
  }, {
    "url": "assets/vendor-supabase-D_t8kiev.js",
    "revision": null
  }, {
    "url": "assets/vendor-react-B2AhFMKx.js",
    "revision": null
  }, {
    "url": "assets/users-C_BSD5vJ.js",
    "revision": null
  }, {
    "url": "assets/user-check-cs-OoM3c.js",
    "revision": null
  }, {
    "url": "assets/triangle-alert-Kl3hw3dO.js",
    "revision": null
  }, {
    "url": "assets/sliders-horizontal-Bs9Uj9N_.js",
    "revision": null
  }, {
    "url": "assets/send-BbU4-L8J.js",
    "revision": null
  }, {
    "url": "assets/save-BPEocGg1.js",
    "revision": null
  }, {
    "url": "assets/receipt-CjYE087D.js",
    "revision": null
  }, {
    "url": "assets/priceAnomaly-BRr1tbxR.js",
    "revision": null
  }, {
    "url": "assets/pencil-BMr2s4q2.js",
    "revision": null
  }, {
    "url": "assets/partsStore-DAmuV-vP.js",
    "revision": null
  }, {
    "url": "assets/package-DVYYhlhU.js",
    "revision": null
  }, {
    "url": "assets/layers-BI7BuvOP.js",
    "revision": null
  }, {
    "url": "assets/info-CqcaZPR5.js",
    "revision": null
  }, {
    "url": "assets/index-DuUirv-U.css",
    "revision": null
  }, {
    "url": "assets/index-DI82BBC-.js",
    "revision": null
  }, {
    "url": "assets/history-BygpadFo.js",
    "revision": null
  }, {
    "url": "assets/filter-DZpCrKA5.js",
    "revision": null
  }, {
    "url": "assets/file-spreadsheet-hqjvsiDb.js",
    "revision": null
  }, {
    "url": "assets/external-link-o_RZBP2j.js",
    "revision": null
  }, {
    "url": "assets/exportUtils-DnybiDy7.js",
    "revision": null
  }, {
    "url": "assets/database-backup-CqAYQ12a.js",
    "revision": null
  }, {
    "url": "assets/database-HugXOGZ8.js",
    "revision": null
  }, {
    "url": "assets/cloud-upload-D44he8wz.js",
    "revision": null
  }, {
    "url": "assets/clock-3-CTDhhx0Y.js",
    "revision": null
  }, {
    "url": "assets/clipboard-check-C2eITZ75.js",
    "revision": null
  }, {
    "url": "assets/circle-x-BvazHVdi.js",
    "revision": null
  }, {
    "url": "assets/calendar-days-CohoHSbo.js",
    "revision": null
  }, {
    "url": "assets/calendar-B3F8p2Y2.js",
    "revision": null
  }, {
    "url": "assets/bell-DySyL1lk.js",
    "revision": null
  }, {
    "url": "assets/ban-BIIQX1M4.js",
    "revision": null
  }, {
    "url": "assets/arrow-right-C7QkGn-q.js",
    "revision": null
  }, {
    "url": "assets/activity-BtC4QpoM.js",
    "revision": null
  }, {
    "url": "assets/ZonesPage-CHQYEeWI.js",
    "revision": null
  }, {
    "url": "assets/TriangleKeyLocationsPage-DYyuGAtd.js",
    "revision": null
  }, {
    "url": "assets/TechnicianMobileApp-FSTyo-6n.js",
    "revision": null
  }, {
    "url": "assets/TechnicianDashboard-tUiTSKIi.js",
    "revision": null
  }, {
    "url": "assets/SystemHealthPage-DkjZZ14_.js",
    "revision": null
  }, {
    "url": "assets/StaffPage-IZYfG20E.js",
    "revision": null
  }, {
    "url": "assets/SmartAssistantPage-CvJ4VRt2.js",
    "revision": null
  }, {
    "url": "assets/ServiceForm-CzIG0vMs.js",
    "revision": null
  }, {
    "url": "assets/ScheduleManagementPage-DWOrPBZ-.js",
    "revision": null
  }, {
    "url": "assets/PartsPage-B26G8URz.js",
    "revision": null
  }, {
    "url": "assets/OperationalReadinessPage-BR28WpKZ.js",
    "revision": null
  }, {
    "url": "assets/NumberStepper-PYIjg9Lo.js",
    "revision": null
  }, {
    "url": "assets/NotificationsPanel-ClrBurq7.js",
    "revision": null
  }, {
    "url": "assets/MarketingFlyout-DtXnLOE8.js",
    "revision": null
  }, {
    "url": "assets/IncompleteDataCenter-7Bxl0vrW.js",
    "revision": null
  }, {
    "url": "assets/DataIntegrityPage-BuJcu9Pw.js",
    "revision": null
  }, {
    "url": "assets/CustomersPage-BGkUsdUJ.js",
    "revision": null
  }, {
    "url": "assets/CustomerReportsPage-YHPj5H_v.js",
    "revision": null
  }, {
    "url": "assets/CustomerPortalView-DHYUz3e6.js",
    "revision": null
  }, {
    "url": "assets/CsvUploadPage-wEZBymkI.js",
    "revision": null
  }, {
    "url": "assets/CpanelSettingsPage-rX2v1LPK.js",
    "revision": null
  }, {
    "url": "assets/ContractsPage-Ds6wAKm5.js",
    "revision": null
  }, {
    "url": "assets/ContractView-kQFGJBdw.js",
    "revision": null
  }, {
    "url": "assets/ChecklistSettingsPage-CT6K4RiK.js",
    "revision": null
  }, {
    "url": "assets/AuditHistoryPage-NxDf7Yww.js",
    "revision": null
  }, {
    "url": "assets/AdminQuickServiceCompletionPage-PzmE7jeo.js",
    "revision": null
  }, {
    "url": "assets/AccessManagementPage-BkFv6Jg_.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "favicon.ico",
    "revision": "574a19b6745bdb5515ca6dcff63d29af"
  }, {
    "url": "pwa-192x192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "icons/icon-192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "icons/icon-512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "manifest.webmanifest",
    "revision": "1f1216864a5c781887515c844f834ec2"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(({
    url
  }) => /\/assets\/xlsx-.*\.js$/i.test(url.pathname), new workbox.StaleWhileRevalidate({
    "cacheName": "tlift-excel-on-demand-v1",
    plugins: [new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(({
    url
  }) => url.pathname.includes("/uploads/") || /\.(?:jpg|jpeg|png|webp)$/i.test(url.pathname), new workbox.CacheFirst({
    "cacheName": "tlift-photos-v1",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 180,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(({
    url
  }) => url.pathname.endsWith("/api/sync.php") || url.pathname.endsWith("/sync.php"), new workbox.NetworkOnly(), 'GET');

}));
