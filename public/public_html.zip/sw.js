/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-135db600'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-512x512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "pwa-192x192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "placeholder.svg",
    "revision": "35707bd9960ba5281c72af927b79291f"
  }, {
    "url": "index.html",
    "revision": "94a6cc9bfd0605108e33ff14b2d2b1c2"
  }, {
    "url": "favicon.ico",
    "revision": "574a19b6745bdb5515ca6dcff63d29af"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "icons/icon-512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "icons/icon-192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "assets/workHoursTracker-fNYfLEcE.js",
    "revision": null
  }, {
    "url": "assets/wallet-euAn_66J.js",
    "revision": null
  }, {
    "url": "assets/vendor-ui-DQrUE-Jh.js",
    "revision": null
  }, {
    "url": "assets/vendor-supabase-D_t8kiev.js",
    "revision": null
  }, {
    "url": "assets/vendor-react-B2AhFMKx.js",
    "revision": null
  }, {
    "url": "assets/users-BJkIWRui.js",
    "revision": null
  }, {
    "url": "assets/user-check-2C6gRFad.js",
    "revision": null
  }, {
    "url": "assets/triangle-alert-6wwBLTPC.js",
    "revision": null
  }, {
    "url": "assets/sliders-horizontal-A5ZFhUsX.js",
    "revision": null
  }, {
    "url": "assets/send-vR6Gt-7e.js",
    "revision": null
  }, {
    "url": "assets/save-BjDxG7n-.js",
    "revision": null
  }, {
    "url": "assets/receipt-Fb3QGvEH.js",
    "revision": null
  }, {
    "url": "assets/priceAnomaly-BRr1tbxR.js",
    "revision": null
  }, {
    "url": "assets/pencil-CCYnCFOZ.js",
    "revision": null
  }, {
    "url": "assets/partsStore-DqtRpsQW.js",
    "revision": null
  }, {
    "url": "assets/package-CB6OPR4f.js",
    "revision": null
  }, {
    "url": "assets/layers-Nabe1gLC.js",
    "revision": null
  }, {
    "url": "assets/info-8IhB52zp.js",
    "revision": null
  }, {
    "url": "assets/index-KPRhp2jd.css",
    "revision": null
  }, {
    "url": "assets/index-Ck2zdaQM.js",
    "revision": null
  }, {
    "url": "assets/history-D3Jb0Ig0.js",
    "revision": null
  }, {
    "url": "assets/filter-BHVC6cVg.js",
    "revision": null
  }, {
    "url": "assets/file-spreadsheet-Bzq1jMyz.js",
    "revision": null
  }, {
    "url": "assets/external-link-DXYkOKGQ.js",
    "revision": null
  }, {
    "url": "assets/exportUtils-C3Loj0lR.js",
    "revision": null
  }, {
    "url": "assets/database-backup-CpVfC-KY.js",
    "revision": null
  }, {
    "url": "assets/database-B5hVy0ZM.js",
    "revision": null
  }, {
    "url": "assets/cloud-upload-DdFHEeEf.js",
    "revision": null
  }, {
    "url": "assets/clock-3-BIZI4Ks7.js",
    "revision": null
  }, {
    "url": "assets/clipboard-check-De14LrrE.js",
    "revision": null
  }, {
    "url": "assets/circle-x-Py0wOQSK.js",
    "revision": null
  }, {
    "url": "assets/calendar-days-Q4xD5S44.js",
    "revision": null
  }, {
    "url": "assets/calendar-Bnr-YyIi.js",
    "revision": null
  }, {
    "url": "assets/bell-DJjLuc_r.js",
    "revision": null
  }, {
    "url": "assets/ban-C1xclAlP.js",
    "revision": null
  }, {
    "url": "assets/arrow-right-fhWU4PVV.js",
    "revision": null
  }, {
    "url": "assets/activity-a5VpD86U.js",
    "revision": null
  }, {
    "url": "assets/ZonesPage-3ZebHe_V.js",
    "revision": null
  }, {
    "url": "assets/TriangleKeyLocationsPage-D7F-hIhp.js",
    "revision": null
  }, {
    "url": "assets/TechnicianMobileApp-BUZojHVo.js",
    "revision": null
  }, {
    "url": "assets/TechnicianDashboard-B7P5wpKH.js",
    "revision": null
  }, {
    "url": "assets/SystemHealthPage-Cb-TUBi-.js",
    "revision": null
  }, {
    "url": "assets/StaffPage-DvjKDMnh.js",
    "revision": null
  }, {
    "url": "assets/SmartAssistantPage-B0ozKpbj.js",
    "revision": null
  }, {
    "url": "assets/ServiceForm-CTWNDS0h.js",
    "revision": null
  }, {
    "url": "assets/ScheduleManagementPage-CAnBFRom.js",
    "revision": null
  }, {
    "url": "assets/PartsPage-DkXsvHN-.js",
    "revision": null
  }, {
    "url": "assets/OperationalReadinessPage-CIO8ma6b.js",
    "revision": null
  }, {
    "url": "assets/NumberStepper-DtXMb5uF.js",
    "revision": null
  }, {
    "url": "assets/NotificationsPanel-CgIzu487.js",
    "revision": null
  }, {
    "url": "assets/MarketingFlyout-Ci_qrAkg.js",
    "revision": null
  }, {
    "url": "assets/IncompleteDataCenter-DdpsQxtw.js",
    "revision": null
  }, {
    "url": "assets/DataIntegrityPage-C6fKoXIL.js",
    "revision": null
  }, {
    "url": "assets/CustomersPage-BXJNuV56.js",
    "revision": null
  }, {
    "url": "assets/CustomerReportsPage-Br-FevRp.js",
    "revision": null
  }, {
    "url": "assets/CustomerPortalView-C0SyrAB8.js",
    "revision": null
  }, {
    "url": "assets/CsvUploadPage-Dfzp475D.js",
    "revision": null
  }, {
    "url": "assets/CpanelSettingsPage-B8Ue8awW.js",
    "revision": null
  }, {
    "url": "assets/ContractsPage-dbZMvQVt.js",
    "revision": null
  }, {
    "url": "assets/ContractView-CU8Rj01_.js",
    "revision": null
  }, {
    "url": "assets/ChecklistSettingsPage-4mOODd0m.js",
    "revision": null
  }, {
    "url": "assets/AuditHistoryPage-BWdJpEMh.js",
    "revision": null
  }, {
    "url": "assets/AdminQuickServiceCompletionPage-CD4ih1Cc.js",
    "revision": null
  }, {
    "url": "assets/AccessManagementPage-BJTgbwoI.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "favicon.ico",
    "revision": "574a19b6745bdb5515ca6dcff63d29af"
  }, {
    "url": "pwa-192x192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "icons/icon-192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "icons/icon-512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "manifest.webmanifest",
    "revision": "1f1216864a5c781887515c844f834ec2"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(({
    url
  }) => /\/assets\/xlsx-.*\.js$/i.test(url.pathname), new workbox.StaleWhileRevalidate({
    "cacheName": "tlift-excel-on-demand-v1",
    plugins: [new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(({
    url
  }) => url.pathname.includes("/uploads/") || /\.(?:jpg|jpeg|png|webp)$/i.test(url.pathname), new workbox.CacheFirst({
    "cacheName": "tlift-photos-v1",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 180,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(({
    url
  }) => url.pathname.endsWith("/api/sync.php") || url.pathname.endsWith("/sync.php"), new workbox.NetworkOnly(), 'GET');

}));
